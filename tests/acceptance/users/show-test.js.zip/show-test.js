import Ember from 'ember';
import { module, test } from 'qunit';
import { make } from 'ember-data-factory-guy';
import TestHelper from 'ember-data-factory-guy/factory-guy-test-helper';
import startApp from 'mylab/tests/helpers/start-app';

var application;

module('Acceptance | users/show', {
  beforeEach: function() {
    application = startApp();
    TestHelper.setup();
    authenticateSession();
  },

  afterEach: function() {
    Ember.run(application, 'destroy');
    invalidateSession();
  }
});

test('visiting /users/show', function(assert) {
  var user = make('user', {name: "user_1"});
  visit('/users/'+user.id);

  andThen(function() {
    assert.equal(currentURL(), '/users/'+user.id);
  });
});



// test("Creates new project", function () {
//   visit('/user/'+user.id);

//   andThen(function () {
//     debugger
//   });
//   // andThen(function () {
//   //   var newProjectName = "Gonzo Project";

//   //   fillIn('input.project-name', newProjectName);

//   //   // Remember, this is for handling an exact match, if you did not care about
//   //   // matching attributes, you could just do: TestHelper.handleCreate('project')
//   //   TestHelper.handleCreate('project', {match: {name: newProjectName, user: user}});

//   //   *
//   //    Let's say that clicking this 'button.add-project', triggers action in the view to
//   //    create project record and looks something like this:
//   //    actions: {
//   //       addProject: function (user) {
//   //         var name = this.$('input.project-name').val();
//   //         var store = this.get('controller.store');
//   //         store.createRecord('project', {name: name, user: user}).save();
//   //       }

//   //   click('button:contains(Add New User)');

//   //   andThen(function () {
//   //     var newProjectDiv = find('li.project:contains(' + newProjectName + ')');
//   //     ok(newProjectDiv[0] !== undefined);
//   //   });
//   // });
// });
