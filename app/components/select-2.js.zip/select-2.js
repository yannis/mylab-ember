import Ember from 'ember';

export default Ember.Component.extend({
  tagName: 'div',
  classNames: ['form-control'],
  classNameBindings: ['inputSize'],

  inputSize: 'input-md',
  placeholder: null,
  currentObject: null,
  multiple: false,

  actions: {
    "select2-selecting": function(val){
      debugger
    }
  },

  didInsertElement: function() {
    var self = this;
    var options = {};
    var currentObject = self.get('currentObject.name')

    console.log("CURRENT OBJECT", currentObject);

    options.multiple = self.get('multiple');
    options.val = self.get('value');
    options.placeholder = self.get('placeholder');

    options.formatSelection = function(item) {
      return self.formatItemForSelect2(item);
    };

    options.formatResult = function(item) {
      return self.formatItemForSelect2(item);
    };

    // options.initSelection = function(element, callback){
    //   console.log("initSelection called", element);
    //   var el = [{text: currentObject.get('name'), id: currentObject.get('id')}]
    //   return callback(el);
    // };

    options.placeholderOption = function(){
      debugger
    };

    options.query = function(query) {
      var select2 = this;

      var filteredContent = self.get("content").reduce(function(results, item) {
        if (select2.matcher(query.term, item.get("name"))) {
          results.push(item);
        }
        return results;
      }, []);

      query.callback({
        results: filteredContent
      });
    };

    // Ember.assert("select2 has to exist", $.fn.select2());
    // Ember.assert("select2 needs a content array", self.get('content'));
    // Ember.assert("select2 needs a selected array", self.get('selected'));

    self._select = self.$().select2(options);
    if (currentObject) {
      debugger
      self._select.data([{text: currentObject.get('name'), id: currentObject.get('id')}]);
    };
    self._select.val(this.get('value'));


    self._select.on("select2-selecting", function(e) {
      self.sendAction('optionSelected', e.val);
    });
  },

  formatItemForSelect2: function(item) {
    if (!item) {
      return;
    }

    var text = item.get("nameForSelectMenu"); //item.get('id');

    return Ember.Handlebars.Utils.escapeExpression(text);
  }
});
